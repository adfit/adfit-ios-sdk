//
//  AdFitSDK.h
//  AdFitSDK
//
//  Created by aiden.gil on 03/07/2017.
//  Copyright © 2017 Kakao Corp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VitalMonitor.h"

//! Project version number for AdFitSDK.
FOUNDATION_EXPORT double AdFitSDKVersionNumber;

//! Project version string for AdFitSDK.
FOUNDATION_EXPORT const unsigned char AdFitSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AdFitSDK/PublicHeader.h>


